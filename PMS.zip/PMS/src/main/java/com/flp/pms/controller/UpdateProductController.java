package com.flp.pms.controller;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.domain.Product;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;
import com.google.gson.Gson;

public class UpdateProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		ServletContext ctx = request.getServletContext();
		IProductService ipProductService = new ProductServiceImpl();
		Product product = ipProductService.search_By_ProductId(Integer.parseInt(request.getParameter("productId")));
		
		Gson json = new Gson();
		String str = json.toJson(product);
		
		ctx.setAttribute("updateJsonFile", str);
		response.sendRedirect("pages/updateexsistingData.html");
	}
}