package com.flp.pms.controller;

import java.util.List;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.domain.Product;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;
import com.google.gson.Gson;

public class searchProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		IProductService iProductService = new ProductServiceImpl();
		PrintWriter out = response.getWriter();
		Gson myjson = new Gson();

		String serachBy = request.getParameter("searchBy");
		String enteredValue = request.getParameter("searchContent");

		/*if ("searchById".equalsIgnoreCase("searchById")) {
			Product product = iProductService.search_By_ProductId(Integer.parseInt("143"));*/
		
		if(serachBy.equalsIgnoreCase("searchById")) {
			Product product = iProductService.search_By_ProductId(Integer.parseInt(enteredValue));
			response.setContentType("application/json");
			String namejson = myjson.toJson(product);
			//out.println(namejson);
			iProductService.storeJsonData(namejson);
			response.sendRedirect("pages/search.html");
		}
		
		if(serachBy.equalsIgnoreCase("searchByName")) {
			Product product = iProductService.search_By_Name(enteredValue);
			response.setContentType("application/json");
			String namejson = myjson.toJson(product);
			//out.println(namejson);
			iProductService.storeJsonData(namejson);
			response.sendRedirect("pages/search.html");
		}
		
		if(serachBy.equalsIgnoreCase("searchBySupplier")) {
			List<Product> product = iProductService.search_By_Rating(Float.parseFloat(enteredValue));
			response.setContentType("application/json");
			String namejson = myjson.toJson(product);
			//out.println(namejson);
			iProductService.storeJsonData(namejson);
			response.sendRedirect("pages/search.html");
		}
		
		if(serachBy.equalsIgnoreCase("searchByCategory")) {
			Product product = iProductService.search_By_ProductId(Integer.parseInt(enteredValue));
			response.setContentType("application/json");
			String namejson = myjson.toJson(product);
			//out.println(namejson);
			iProductService.storeJsonData(namejson);
			response.sendRedirect("pages/search.html");
		}
		
		if(serachBy.equalsIgnoreCase("searchByRating")) {
			Product product = iProductService.search_By_ProductId(Integer.parseInt(enteredValue));
			response.setContentType("application/json");
			String namejson = myjson.toJson(product);
			//out.println(namejson);
			iProductService.storeJsonData(namejson);
			response.sendRedirect("pages/search.html");
		}
	}
}