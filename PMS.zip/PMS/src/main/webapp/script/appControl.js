app.controller("custCtrl",function($scope, $http) {

					/*
					 * $http.get('http://localhost:8083/PMS/createPageController?action=category')
					 * .success(function(response) { $scope.customers =
					 * response; }).error(function(errMsg) { $scope.errmsg =
					 * errMsg; }); });
					 */

					$scope.getCategories = function() {
						var url = "http://localhost:8080/PMS/createPageController?action=category";
						// var url=
						// "http://localhost:8080/PMS/createPageController?action=category";
						$http.get(url).success(function(response) {
							$scope.categories = response;
						}).error(function(msg) {
							$scope.categories = msg;
						});
					};

					$scope.getSubCategories = function() {
						var url = "http://localhost:8080/PMS/createPageController?action=subcategory";

						$http.get(url).success(function(response) {
							$scope.subcategories = response;
						}).error(function(msg) {
							$scope.subcategories = msg;
						});
					};

					$scope.getSuppliers = function() {
						var url = "http://localhost:8080/PMS/createPageController?action=supplier";

						$http.get(url).success(function(response) {
							$scope.suppliers = response;
						}).error(function(msg) {
							$scope.suppliers = msg;
						});
					};

					$scope.getDiscounts = function() {
						var url = "http://localhost:8080/PMS/createPageController?action=discount";

						$http.get(url).success(function(response) {
							$scope.discounts = response;
						}).error(function(msg) {
							$scope.discounts = msg;
						});
					};

					// product list
					$scope.getProducts = function() {
						var url = "http://localhost:8080/PMS/createPageController?action=productList";
						$http.get(url).success(function(response) {
							$scope.products = response;
						}).error(function(errMsg) {
							$scope.errmsg = errMsg;
						});
					};

					$scope.searchProductGeneric = function() {
						var url = "http://localhost:8080/PMS/RetriveJasonForSearchServlet";
						$http.get(url).success(function(response) {
							$scope.searchGeneric = response;
						}).error(function(errMsg) {
							$scope.errmsg = errMsg;
						});
					};
					
					
					$scope.updateProduct = function() {
						var url = "http://localhost:8080/PMS/RetriveJasonForUpdateServlet";
						$http.get(url).success(function(response) {
							$scope.updateProducts = response;
						}).error(function(errMsg) {
							$scope.errmsg = errMsg;
						});
					};

				});
